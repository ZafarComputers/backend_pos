

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Vendors</h2>
    <a href="<?php echo e(route('vendors.create')); ?>" class="btn btn-primary">Add Vendor</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th><th>Name</th><th>CNIC</th><th>City</th><th>Status</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vendor->id); ?></td>
                <td><?php echo e($vendor->first_name); ?> <?php echo e($vendor->last_name); ?></td>
                <td><?php echo e($vendor->cnic); ?></td>
                <td><?php echo e($vendor->city->name ?? '-'); ?></td>
                <td><?php echo e($vendor->status); ?></td>
                <td>
                    <a href="<?php echo e(route('vendors.edit', $vendor)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('vendors.destroy', $vendor)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($vendors->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/vendors/index.blade.php ENDPATH**/ ?>