

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>SubCategories</h2>
    <a href="<?php echo e(route('subcategories.create')); ?>" class="btn btn-primary">Add SubCategory</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Image</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($subcategory->id); ?></td>
                <td><?php echo e($subcategory->title); ?></td>
                <td><?php echo e($subcategory->category->title ?? '-'); ?></td>
                <td><?php echo e($subcategory->status); ?></td>
                <td>
                    <?php if($subcategory->img_path): ?>
                        <img src="<?php echo e($subcategory->img_path); ?>" width="50">
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('subcategories.edit', $subcategory)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('subcategories.destroy', $subcategory)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($subcategories->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/subcategories/index.blade.php ENDPATH**/ ?>