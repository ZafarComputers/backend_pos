

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Products</h2>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">Add Product</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>Design Code</th>
                <th>Category</th>
                <th>Sale Price</th>
                <th>Stock</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($product->image_path): ?>
                        <img src="<?php echo e(asset('storage/'.$product->image_path)); ?>" alt="product image" width="80">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td><?php echo e($product->title); ?></td>
                <td><?php echo e($product->design_code); ?></td>
                <td><?php echo e($product->subCategory->title); ?></td>
                <td><?php echo e($product->sale_price); ?></td>
                <td><?php echo e($product->opening_stock_quantity); ?></td>
                <td><?php echo e($product->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/products/index.blade.php ENDPATH**/ ?>