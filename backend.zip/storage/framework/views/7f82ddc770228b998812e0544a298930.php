

<?php $__env->startSection('title', 'Add New Employee'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="px-6">
            <h1 class="text-3xl font-bold mb-6 text-black">Add New Employee</h1>

            <!-- Display error messages if any -->
            <?php if($errors->any()): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-black p-4 mb-6" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Form to add a new employee -->
            <form action="<?php echo e(route('employees.store')); ?>" method="POST" class="bg-white shadow-md rounded-lg p-6 w-full">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-black">Name</label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-black">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div class="mb-4">
                    <label for="position" class="block text-sm font-medium text-black">Position</label>
                    <input type="text" name="position" id="position" value="<?php echo e(old('position')); ?>"
                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div class="mb-4">
                    <label for="city_id" class="block text-sm font-medium text-black">City</label>
                    <select name="city_id" id="city_id" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <?php $__currentLoopData = \App\Models\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-black">Status</label>
                    <div class="flex space-x-2">
                        <button type="button" data-status="active"
                                class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition duration-200 <?php echo e(old('status') == 'active' ? 'bg-green-600' : ''); ?>"
                                onclick="this.form.status.value='active'; this.classList.add('bg-green-600'); document.querySelector('[data-status=\"inactive\"]').classList.remove('bg-red-600');">
                            Active
                        </button>
                        <button type="button" data-status="inactive"
                                class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition duration-200 <?php echo e(old('status') == 'inactive' ? 'bg-red-600' : ''); ?>"
                                onclick="this.form.status.value='inactive'; this.classList.add('bg-red-600'); document.querySelector('[data-status=\"active\"]').classList.remove('bg-green-600');">
                            Inactive
                        </button>
                        <input type="hidden" name="status" value="<?php echo e(old('status') ?? 'active'); ?>">
                    </div>
                </div>
                <div class="flex justify-end">
                    <button type="submit"
                            class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition duration-200">
                        Save Employee
                    </button>
                    <a href="<?php echo e(route('employees.index')); ?>"
                       class="ml-4 text-black hover:text-gray-600">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/employees/create.blade.php ENDPATH**/ ?>