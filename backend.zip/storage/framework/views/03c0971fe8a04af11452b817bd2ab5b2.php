

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>User Profile</h1>

    <div class="card p-3">
        <p><strong>ID:</strong> <?php echo e($user->id); ?></p>
        <p><strong>Name:</strong> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
        <p><strong>Cell No 1:</strong> <?php echo e($user->cell_no1 ?? '-'); ?></p>
        <p><strong>Cell No 2:</strong> <?php echo e($user->cell_no2 ?? '-'); ?></p>
        <p><strong>Status:</strong> <?php echo e(ucfirst($user->status)); ?></p>
        <p><strong>Role:</strong> <?php echo e($user->role->name ?? '-'); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/users/profile.blade.php ENDPATH**/ ?>