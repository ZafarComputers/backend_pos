

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>POS Invoices</h2>
    <a href="<?php echo e(route('pos.create')); ?>" class="btn btn-primary mb-3">New Invoice</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Customer</th>
                <th>Invoice Date</th>
                <th>Amount</th>
                <th>Tax</th>
                <th>Discount %</th>
                <th>Discount Amt</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($invoice->customer->name ?? 'N/A'); ?></td>
                <td><?php echo e($invoice->inv_date); ?></td>
                <td><?php echo e($invoice->inv_amout); ?></td>
                <td><?php echo e($invoice->tax); ?></td>
                <td><?php echo e($invoice->discPer); ?></td>
                <td><?php echo e($invoice->discount); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($pos->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/pos/index.blade.php ENDPATH**/ ?>