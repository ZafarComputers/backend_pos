

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>POS Returns</h2>
    <a href="<?php echo e(route('pos_returns.create')); ?>" class="btn btn-primary mb-3">Add Return</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Customer</th>
                <th>Return Date</th>
                <th>POS Invoice No</th>
                <th>Return Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ret->customer->name ?? 'N/A'); ?></td>
                <td><?php echo e($ret->invRet_date); ?></td>
                <td><?php echo e($ret->pos_inv_no); ?></td>
                <td><?php echo e($ret->return_inv_amout); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($returns->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/pos_returns/index.blade.php ENDPATH**/ ?>