<?php if($deprecated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkgoldenrod", 'text' => 'deprecated']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\myPractice\Flutter\POS\backend\vendor\knuckleswtf\scribe\src/../resources/views//components/badges/deprecated.blade.php ENDPATH**/ ?>