

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Purchases</h2>
    <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-primary mb-3">New Purchase</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Date</th>
                <th>Vendor Inv #</th>
                <th>Amount</th>
                <th>Discount</th>
                <th>Final</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($purchase->date); ?></td>
                <td><?php echo e($purchase->ven_inv_no); ?></td>
                <td><?php echo e($purchase->inv_amount); ?></td>
                <td><?php echo e($purchase->discount_amt); ?></td>
                <td><?php echo e($purchase->inv_amount - $purchase->discount_amt); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($purchases->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/purchases/index.blade.php ENDPATH**/ ?>