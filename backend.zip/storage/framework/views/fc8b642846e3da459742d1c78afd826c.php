

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Purchase Returns</h2>
    <a href="<?php echo e(route('purchase_returns.create')); ?>" class="btn btn-primary mb-3">New Return</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Date</th>
                <th>Vendor</th>
                <th>Product</th>
                <th>Return Amount</th>
                <th>Purchase Ref</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($return->date); ?></td>
                <td><?php echo e($return->vendor->first_name ?? 'N/A'); ?></td>
                <td><?php echo e($return->product->title ?? 'N/A'); ?></td>
                <td><?php echo e($return->return_inv_amount); ?></td>
                <td>#<?php echo e($return->purchase->id ?? 'N/A'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($returns->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/purchase_returns/index.blade.php ENDPATH**/ ?>