<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>

    <?php if($errors->any()): ?>
        <div>
            <strong>Whoops! Something went wrong.</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url('/register')); ?>">
        <?php echo csrf_field(); ?>

        <label>First Name:</label>
        <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required><br>

        <label>Last Name:</label>
        <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" required><br>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required><br>

        <label>Password:</label>
        <input type="password" name="password" required><br>

        <label>Confirm Password:</label>
        <input type="password" name="password_confirmation" required><br>

        <button type="submit">Register</button>
    </form>
</body>
</html>
<?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/auth/register.blade.php ENDPATH**/ ?>