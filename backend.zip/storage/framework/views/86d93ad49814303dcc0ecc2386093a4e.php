

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Colors</h2>
    <a href="<?php echo e(route('colors.create')); ?>" class="btn btn-primary">Add Color</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th><th>Title</th><th>Status</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($color->id); ?></td>
                <td><?php echo e($color->title); ?></td>
                <td><?php echo e($color->status); ?></td>
                <td>
                    <a href="<?php echo e(route('colors.edit', $color)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('colors.destroy', $color)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($colors->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/colors/index.blade.php ENDPATH**/ ?>