

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>POS Invoice Details</h2>
    <a href="<?php echo e(route('pos_details.create')); ?>" class="btn btn-primary mb-3">Add Detail</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>POS ID</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Sale Price</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>#<?php echo e($detail->pos->id ?? 'N/A'); ?></td>
                <td><?php echo e($detail->product->title ?? 'N/A'); ?></td>
                <td><?php echo e($detail->qty); ?></td>
                <td><?php echo e($detail->sale_price); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($details->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\myPractice\Flutter\POS\backend\resources\views/pos_details/index.blade.php ENDPATH**/ ?>