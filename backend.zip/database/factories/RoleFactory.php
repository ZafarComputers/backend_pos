<?php

// database/factories/RoleFactory.php
namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class RoleFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => $this->faker->unique()->randomElement([
                'Super Admin', 'Admin', 'Salesman', 'Accountant'
            ]),
        ];
    }
}
