<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    use HasFactory;

    protected $fillable = [
        'pur_date', 'pur_inv_barcode', 'vendor_id', 'ven_inv_no',
        'ven_inv_date', 'ven_inv_ref', 'description',
        'discount_percent', 'discount_amt', 'inv_amount', 'payment_status',
    ];

    public function details() {
        return $this->hasMany(PurchaseDetail::class);
    }

    public function vendor() {
        return $this->belongsTo(Vendor::class);
    }
}
