<?php

// app/Http/Controllers/SizeController.php
namespace App\Http\Controllers;

use App\Models\Size;
use Illuminate\Http\Request;

class SizeController extends Controller
{
    public function index() {
        $sizes = Size::paginate(10);
        return view('sizes.index', compact('sizes'));
    }

    public function create() {
        return view('sizes.create');
    }

    public function store(Request $request) {
        $request->validate([
            'title' => 'required|string|unique:sizes',
            'status' => 'required|in:Active,Inactive',
        ]);

        Size::create($request->all());
        return redirect()->route('sizes.index')->with('success', 'Size created successfully.');
    }

    public function show(Size $size) {
        return view('sizes.show', compact('size'));
    }

    public function edit(Size $size) {
        return view('sizes.edit', compact('size'));
    }

    public function update(Request $request, Size $size) {
        $request->validate([
            'title' => 'required|string|unique:sizes,title,' . $size->id,
            'status' => 'required|in:Active,Inactive',
        ]);

        $size->update($request->all());
        return redirect()->route('sizes.index')->with('success', 'Size updated successfully.');
    }

    public function destroy(Size $size) {
        $size->delete();
        return redirect()->route('sizes.index')->with('success', 'Size deleted successfully.');
    }
}
