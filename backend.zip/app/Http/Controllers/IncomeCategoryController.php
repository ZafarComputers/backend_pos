<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IncomeCategoryController extends Controller
{
    //
}
